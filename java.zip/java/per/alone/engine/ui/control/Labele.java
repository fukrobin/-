package per.alone.engine.ui.control;

public class Labele extends Labeled {
}