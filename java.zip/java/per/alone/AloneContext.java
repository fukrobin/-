package per.alone;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import per.alone.stage.Window;

/**
 * //TODO
 *
 * @author fkrobin
 * @date 2021/9/20 18:33
 */
@Setter
@Getter
@Builder
public class AloneContext {

    private Window window;

}
